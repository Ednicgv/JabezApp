<?php
 /*	
	Indice
	Autor: Edni García
	Fecha: Abril 2017
*/
ob_start();
session_start();
include_once(dirname(__FILE__). '/config.inc');
$prefijo='';
?>

<html> 
    <head>
        <meta charset="utf-8">
        <title>JabezApp</title>
        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Google Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Raleway:100,200,300,700,800,900' rel='stylesheet' type='text/css'>
        <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">    
        <!-- Library CSS -->
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/bootstrap-theme.css">
        <link rel="stylesheet" href="css/fonts/font-awesome/css/font-awesome.css">
        <link rel="stylesheet" href="css/animations.css" media="screen">
        <link rel="stylesheet" href="css/superfish.css" media="screen">
        <link rel="stylesheet" href="css/revolution-slider/css/settings.css" media="screen">
        <link rel="stylesheet" href="css/revolution-slider/css/extralayers.css" media="screen">
        <link rel="stylesheet" href="css/prettyPhoto.css" media="screen">
        <!-- Theme CSS -->
        <link rel="stylesheet" href="css/style.css">
        <!-- Skin -->
        <link rel="stylesheet" href="css/colors/green.css" class="colors">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="css/theme-responsive.css">
        <!-- Switcher CSS -->
        <link href="css/switcher.css" rel="stylesheet">
        <link href="css/spectrum.css" rel="stylesheet">
        <!-- Favicons -->
        <link rel="shortcut icon" href="img/ico/favicon.ico">
        
    </head>

    <body class="home">
        <div class="page-mask">
            <div class="page-loader">
                <div class="spinner"></div>
                Loading...
            </div>
        </div>
        <?php 
		 include_once(DIR_MODULOS.'topbar.php'); 	
		 include_once(DIR_MODULOS.'header.php');
		 include_once(DIR_MODULOS.'slider.php');
		 include_once(DIR_MODULOS.'main.php');
		 include_once(DIR_MODULOS.'footer.php');
		?>
    </body>
</html>