<?php
 /*	
	Indice
	Autor: Edni García
	Fecha: Abril 2017
*/
include_once(dirname(__FILE__). '/../config.inc');
$prefijo='../';
?>

<html> 
    <head>
        <meta charset="utf-8">
        <title>JabezApp- Portafolio</title>
        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Google Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Raleway:100,200,300,700,800,900' rel='stylesheet' type='text/css'>
        <!-- Library CSS -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/bootstrap-theme.css">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/fonts/font-awesome/css/font-awesome.css">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/animations.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/superfish.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/revolution-slider/css/settings.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/revolution-slider/css/extralayers.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/prettyPhoto.css" media="screen">
        <!-- Theme CSS -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/style.css">
        <!-- Skin -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/colors/green.css" class="colors">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/theme-responsive.css">
        <!-- Switcher CSS -->
        <link href="<?php echo $prefijo;?>css/switcher.css" rel="stylesheet">
        <link href="<?php echo $prefijo;?>css/spectrum.css" rel="stylesheet">
        <!-- Favicons -->
        <link rel="shortcut icon" href="<?php echo $prefijo;?>img/ico/favicon.ico">
    </head>

    <body class="home">
        <div class="page-mask">
            <div class="page-loader">
                <div class="spinner"></div>
                Loading...
            </div>
        </div>

        <?php 	
		 include_once(DIR_MODULOS.'header.php');	 
		?>

   <!-- Main Section -->
    <section id="main">
        <div class="breadcrumb-wrapper">
            <div class="pattern-overlay">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-xs-12 col-sm-6">
                            <h2 class="title">Portafolio</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Main Content-->
        <div class="content margin-top60 margin-bottom60">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div id="options">
                            <h2>Chequea nuestro trabajo</h2>
                            <ul id="filters" class="option-set clearfix" data-option-key="filter">
                                <li><a href="#filter" data-option-value="*" class="selected">Todo</a></li>
                                <li><a href="#filter" data-option-value=".web">WebSites</a></li>
                                <li><a href="#filter" data-option-value=".wp">Aplicaciones</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-lg-12  col-md-12 col-sm-12 col-xs-12 portfolio-three-column portfolio-wrap">
                                
                        <!-- Portfolio -->
                        <div class="portfolio">
                            <!-- grid -->
                            <div class="grid">
                                <!-- Item 1 -->
                                <figure class="effect-zoe portfolio-border wp jquery item">
                                    <img src="<?php echo $prefijo;?>img/portfolio/jabeztime.jpg" alt="img1"/>
                                    <figcaption>
                                        <h2>Jabez <span>Time</span></h2>
                                        <span><a href="../modulos/download.php" ><i class="fa fa-share"></i></a></span>                  
                                        <p>Aplicación para el Control de Tiempo de Empleados</p>
                                    </figcaption>
                                </figure>
                                <!-- /Item 1 -->

                                <!-- Item 2 -->
                                <figure class="effect-zoe portfolio-border web css item">
                                    <img src="<?php echo $prefijo;?>img/portfolio/martinezpainting.jpg" alt="img2"/>
                                    <figcaption>
                                        <h2 align="center">Martinez  Painting<span> Group</span></h2>                                         
                                        <p class="text-justify">System Work Order</p>
                                    </figcaption>
                                </figure>
                                <!-- /Item 2 -->

                                <!-- Item 3 -->
                                <figure class="effect-zoe portfolio-border php jquery web item">
                                    <img src="<?php echo $prefijo;?>img/portfolio/partymasters.jpg" alt="img3"/></a>
                                    <figcaption>
                                        <h2>The Party <span>Masters</span></h2>
                                        <span><a href="http://www.thepartymasters.us"><i class="fa fa-share"></i></a></span>                  
                                        <p>Sitio Web</p>
                                    </figcaption>
                                </figure>
                                <!-- /Item 3 -->

                                <!-- Item 4 -->
                                <figure class="effect-zoe portfolio-border web jquery css item">
                                    <img src="<?php echo $prefijo;?>img/portfolio/ieventos.jpg" alt="img4"/>
                                    <figcaption>
                                        <h2>i- <span>Eventos</span></h2>
                                        <span><a href="http://www.i-eventos.com/"><i class="fa fa-share"></i></a></span>                          
                                        <p>WebSite</p>
                                    </figcaption>
                                </figure>
                                <!-- /Item 4 -->


                                
                                
                            </div>
                            <!--/grid-->
                        </div>
                        <!-- /Portfolio -->
                    </div>
                </div>
            </div>
        </div>
        <!-- /Main Content-->
    </section>
    <!-- /Main Section --> 

        <!-- The Scripts -->
        <script src="js/jquery.min.js"></script>
        <script src="js/jquery-migrate-1.0.0.js"></script>
        <script src="js/jquery-ui.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/revolution-slider/js/jquery.themepunch.plugins.min.js"></script> 
        <script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/jquery.parallax.js"></script>
        <script src="js/jquery.wait.js"></script>
        <script src="js/fappear.js"></script> 
        <script src="js/modernizr-2.6.2.min.js"></script>
        <script src="js/jquery.bxslider.min.js"></script>
        <script src="js/jquery.prettyPhoto.js"></script>
        <script src="js/superfish.js"></script>
        <script src="js/tweetMachine.js"></script>
        <script src="js/tytabs.js"></script>
        <script src="js/jquery.gmap.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.countTo.js"></script>
        <script src="js/jflickrfeed.js"></script>
        <script src="js/imagesloaded.pkgd.min.js"></script>
        <script src="js/waypoints.min.js"></script>
        <script src="js/wow.js"></script>
        <script src="js/jquery.fitvids.js"></script>
        <script src="js/spectrum.js"></script>
        <script src="js/switcher.js"></script>
        <script src="js/custom.js"></script>
    </body>
</html>
<? 	include_once(DIR_MODULOS.'footer.php'); ?>