<?php
 /*	
	Indice
	Autor: Edni García
	Fecha: Abril 2017
*/
include_once(dirname(__FILE__). '/../config.inc');
$prefijo='../';
?>

<html> 
    <head>
        <meta charset="utf-8">
        <title>JabezApp- Prices</title>
        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Google Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Raleway:100,200,300,700,800,900' rel='stylesheet' type='text/css'>
        <!-- Library CSS -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/bootstrap-theme.css">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/fonts/font-awesome/css/font-awesome.css">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/animations.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/superfish.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/revolution-slider/css/settings.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/revolution-slider/css/extralayers.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/prettyPhoto.css" media="screen">
        <!-- Theme CSS -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/style.css">
        <!-- Skin -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/colors/green.css" class="colors">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/theme-responsive.css">
        <!-- Switcher CSS -->
        <link href="<?php echo $prefijo;?>css/switcher.css" rel="stylesheet">
        <link href="<?php echo $prefijo;?>css/spectrum.css" rel="stylesheet">
        <!-- Favicons -->
        <link rel="shortcut icon" href="<?php echo $prefijo;?>img/ico/favicon.ico">
    </head>

    <body class="home">

        <?php 
		 include_once(DIR_MODULOS.'topbar.php'); 	
		 include_once(DIR_MODULOS.'header.php');	 
		?>

        <!-- The Scripts -->
        <script src="js/jquery.min.js"></script>
        <script src="js/jquery-migrate-1.0.0.js"></script>
        <script src="js/jquery-ui.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/revolution-slider/js/jquery.themepunch.plugins.min.js"></script> 
        <script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/jquery.parallax.js"></script>
        <script src="js/jquery.wait.js"></script>
        <script src="js/fappear.js"></script> 
        <script src="js/modernizr-2.6.2.min.js"></script>
        <script src="js/jquery.bxslider.min.js"></script>
        <script src="js/jquery.prettyPhoto.js"></script>
        <script src="js/superfish.js"></script>
        <script src="js/tweetMachine.js"></script>
        <script src="js/tytabs.js"></script>
        <script src="js/jquery.gmap.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.countTo.js"></script>
        <script src="js/jflickrfeed.js"></script>
        <script src="js/imagesloaded.pkgd.min.js"></script>
        <script src="js/waypoints.min.js"></script>
        <script src="js/wow.js"></script>
        <script src="js/jquery.fitvids.js"></script>
        <script src="js/spectrum.js"></script>
        <script src="js/switcher.js"></script>
        <script src="js/custom.js"></script>
    </body>
</html>
<? 	include_once(DIR_MODULOS.'footer.php'); ?>