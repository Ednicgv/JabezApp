<?php
 /*	
	Indice
	Autor: Edni García
	Fecha: Abril 2017
*/
include_once(dirname(__FILE__). '/../config.inc');
$prefijo='../';
?>

<html> 
    <head>
        <meta charset="utf-8">
        <title>JabezApp- Descargas</title>
        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Google Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Raleway:100,200,300,700,800,900' rel='stylesheet' type='text/css'>
        <!-- Library CSS -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/bootstrap-theme.css">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/fonts/font-awesome/css/font-awesome.css">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/animations.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/superfish.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/revolution-slider/css/settings.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/revolution-slider/css/extralayers.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/prettyPhoto.css" media="screen">
        <!-- Theme CSS -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/style.css">
        <!-- Skin -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/colors/green.css" class="colors">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/theme-responsive.css">
        <!-- Switcher CSS -->
        <link href="<?php echo $prefijo;?>css/switcher.css" rel="stylesheet">
        <link href="<?php echo $prefijo;?>css/spectrum.css" rel="stylesheet">
        <!-- Favicons -->
        <link rel="shortcut icon" href="<?php echo $prefijo;?>img/ico/favicon.ico">
    </head>

<body class="home">
    <div class="page-mask">
        <div class="page-loader">
            <div class="spinner"></div>
            Loading...
        </div>
    </div>
        <?php 	
         include_once(DIR_MODULOS.'topbar.php'); 
		 include_once(DIR_MODULOS.'header.php');	
		?>

    <!-- Main Section -->
    <section id="main">
        <div class="breadcrumb-wrapper">
            <div class="pattern-overlay">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-xs-12 col-sm-6">
                            <h2 class="title">Descargas</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Main Content-->
<div class="content margin-top60 margin-bottom60">
        <div class="container">
            <div class="row">
                <!-- Left Section -->
                <div class="posts-block col-lg-8 col-md-8 col-sm-8 col-xs-12">
                    <!-- Recent work -->
                    <div class="recentwork_wrapper">
                        <!-- Slider -->
                        <div class="gallery-image">
                            <img src="../img/gallery/jabeztime.png">     
                            <div class="clearfix"></div>
                            <!-- /Slider --> 
                        </div>
                    </div>
                    <!-- /Recent work -->
                </div>
                <!-- /Left Section -->
                
                <!-- Project Summary -->
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 sidebar">
                    <div class="widget">
                        <h1 class="title">Jabez Time</h1>
                        <h3><p>Lleve el control de sus horas trabajadas.</p>
                        <p><span class="coral">Jabez Time</span> te ofrece los datos de control de la actividad laboral más reciente.</p></h3>
                    </div>
                    <!-- Project Description End -->  
                    <div class="widget">
                        <div class="member-social dark">
                            <a class="facebook" href="#"><i class="fa fa-location-arrow"></i></a>
                            <h3>Geolocalización</h3>
                            <a class="twitter" href="#"><i class="fa fa-clock-o"></i></a>
                            <h3>Control de Tiempo</h3>
                            <a class="dribbble" href="#"><i class="fa fa-bar-chart"></i></a>
                            <h3>Estadísticas</h3>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <!-- Project Details Start -->
                    <!--<div class="widget project_details">
                        <h3 class="title">Detalles</h3>
                        <div class="details-content"><span><strong>Fecha</strong><em>Noviembre 13, 2015</em></span>
                            <span><strong>Ultima Actualización</strong><em>Marzo 2, 2016</em></span>
                            <span><strong>Versión</strong><em>0.14.0</em></span>
                        </div>
                        <div class="clearfix"></div>
                    </div>-->
                    <!--<div class="widget">
                        <a href="#" class="btn-normal btn-color"><i class="fa fa-hand-right icon-large"></i>  Precios</a>
                    </div>-->
                    <h3>Descargalo gratis</h3>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <a href="https://play.google.com/store/apps/details?id=com.jabezapp.timecontrol&hl=en"><img src="../img/gallery/appstore.png"> </a>
                        <a href="https://itunes.apple.com/us/app/jabez-time/id1047275179?mt=8"> <img src="../img/gallery/google.png"> </a>
                    </div>
                </div>
                <!-- /Project Summary -->
            </div>
            <!-- Star -->
            <div class="star">
                <div class="container">
                    <div class="row text-center">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="star-divider">
                                <div class="star-divider-icon">
                                    <i class=" fa fa-star"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Star -->  

            <!-- Recent work -->
            <div class="recentwork_wrapper">
                <h2>Detalles</h2>
                <div class="post-content top-pad">
                    <h4><p>
                        Permite manejar: 
                            <li> Registro de su tiempo trabajado durante su semana laboral.</li>
                            <li> Registro de todas sus jornadas laborales.</li>
                            <li> Registro de su ubicación geográfica al inicio y al final de su de su jornada laboral.</li>
                            <li> Estadística de horas VS ingresos semanales.</li>
                                       
                       Ademas, puede establecer el día de inicio de su semana laboral.</h4>
                    </p>
                    </p>
                </div>
            </div>
            <!-- /Recent work -->
        </div>
</div>
<!-- /Main Content-->
</section>
<!-- /Main Section --> 
    </body>
</html>
<? 	include_once(DIR_MODULOS.'footer.php'); ?>