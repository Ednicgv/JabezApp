<!-- Header -->
<header id="header">
    <!-- Header Top Bar -->
    <div class="top-bar">
        <div class="slidedown collapse">
            <div class="container">
                <div class="pull-left">
                    <ul class="social social-icons-footer-bottom pull-left">
                        <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li class="dribbble"><a href="#"><i class="fa fa-instagram"></i></a></li>
                    </ul>
                </div>
                <div class="phone-login pull-right">
                    <a><i class="fa fa-phone"></i> Llámanos : (407) 371-8653</a>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- /Header --> 