<!-- Wrap -->
<div class="wrap">
    <!-- Main Section -->
    <section id="main">               
        <!-- Product Content -->
        <div class="product-lead bottom-pad margin-top100">
            <div class="pattern-overlay">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-sm-12 col-xs-12 text-center wow fadeInLeft">
                            <img class="app-img" src="img/webdesign.png" alt="iPhone5c">
                        </div>
                        <div class="col-md-6 col-sm-12 col-xs-12 wow fadeInRight">
                            <div class="app-service padding-bottom50">
                                <h2 class="light">Proveemos cualquier tipo de diseño y desarrollo de aplicaciones para iPhone & Android.</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Product Content --> 


        <!-- Services -->
        <div id="services">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="padding-top40 text-center">
                                <h2 class="fadeInRight">Nuestros Servicios</h2>
                                <h4 class="fadeInRight">
                                    Contamos con un gran equipo especializado en Diseño Web, Desarrollo de Aplicaciones Multiplataformas y manejo de Redes Sociales.
                                </h4>
                            </div>
                        </div>
                    </div>
                </div>  
            
             <div class="container">
                <!-- services --> 
                <div class="row padding-top40">
                    <div class="col-lg-3 col-md-3 col-sm-3">
                        <div class="content-box big">
                            <div class="ch-info-wrap">
                                <div class="ch-info">
                                    <div class="ch-info-front ch-img-1"><i class="fa fa-desktop"></i></div>
                                </div>
                            </div>
                            <div class="content-box-info">
                                <h3>CONTENIDO</h3>
                                <p>
                                 Redes Sociales, Contenido Web, Personal Branding.
                                </p>
                            </div>
                            <div class="border-bottom margin-top30">
                            </div>
                            <div class="border-bottom">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-3">
                        <div class="content-box big">
                            <div class="ch-info-wrap">
                                <div class="ch-info">
                                    <div class="ch-info-front ch-img-1"> <i class="fa fa-pencil"></i></div>
                                    <div class="ch-info-back">
                                        <i class="fa fa-pencil"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="content-box-info">
                                <h3>DESARROLLO</h3>
                                <p>
                                    Páginas Web, E-Commerce, Aplicaciones Móviles.
                                </p>
                            </div>
                            <div class="border-bottom margin-top30">
                            </div>
                            <div class="border-bottom">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-3">
                        <div class="content-box big">
                            <div class="ch-info-wrap">
                                <div class="ch-info">
                                    <div class="ch-info-front ch-img-1"><i class="fa fa-facebook"></i></div>
                                    <div class="ch-info-back">
                                        <i class="fa fa-facebook"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="content-box-info">
                                <h3>PROMOCION</h3>
                                <p>
                                    Publicidad en Redes Sociales, SEO, Digital Media. 
                                </p>
                            </div>
                            <div class="border-bottom margin-top30">
                            </div>
                            <div class="border-bottom">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-3">
                        <div class="content-box big">
                            <div class="ch-info-wrap">
                                <div class="ch-info">
                                    <div class="ch-info-front ch-img-1"><i class="fa fa-line-chart"></i></div>
                                    <div class="ch-info-back">
                                        <i class="fa fa-facebook"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="content-box-info">
                                <h3>ANALYTICS</h3>
                                <p>
                                    Monitoreo, Reportes de Desempeño. 
                                </p>
                            </div>
                            <div class="border-bottom margin-top30">
                            </div>
                            <div class="border-bottom">
                            </div>
                        </div>
                    </div>
                </div>
            <!-- /Promo -->
        </div>
        <!-- /Services --> 
        </div>
        <!-- /Services --> 

        <!-- Slogan -->
        <div class="slogan margin-top100 bottom-pad-small">
            <div class="pattern-overlay">
                <div class="container">
                    <div class="row">
                        <div class="slogan-content">
                            <div class="col-lg-10 col-md-10 wow fadeInLeft">
                                <h2 class="slogan-title">Conseguiste razones para trabajar con nosotros? Contáctanos!</h2>
                            </div>
                            <div class="col-lg-2 col-md-2 wow fadeInRight">
                                <div class="get-started wow fadeIn">
                                    <a href="<?php echo $prefijo;?>modulos/contact.php" class="btn-special btn-grey pull-right">CONTACTANOS</a>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Slogan -->                                                          
    </section>
    <!-- /Main Section -->
    <!-- Scroll To Top --> 
    <a href="#" class="scrollup"><i class="fa fa-angle-up"></i></a>
</div>
<!-- /Wrap -->