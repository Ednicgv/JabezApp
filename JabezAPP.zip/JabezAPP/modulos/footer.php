<!-- Footer -->
<footer id="footer">
    <div class="pattern-overlay">
        <!-- Footer Top -->
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <section class="col-lg-3 col-md-3 col-xs-12 col-sm-3 footer-three wow fadeIn">
                        <h3 class="light">Contáctanos</h3>
                        <ul class="contact-us">
                            <li>
                                <i class="fa fa-envelope"></i>
                                <p><a href="mailto:info@jabezapp.com">info@jabezapp.com</a></p>
                                <i class="fa fa-phone"></i>
                                <p>(407) 279-8544</p>
                            </li>
                        </ul>
                    </section>
                    <section class="col-lg-3 col-md-3 col-xs-12 col-sm-3 footer-two wow fadeIn">
                        <h3 class="light">Mapa del Sitio</h3>
                        <ul>
                            <li><a href="<?php echo $prefijo;?>index.php">Home</a></li>
                            <li><a href="<?php echo $prefijo;?>modulos/download.php">Descargas</a></li>
                            <li><a href="<?php echo $prefijo;?>modulos/portfolio.php">Portafolio</a></li>
                            <li><a href="<?php echo $prefijo;?>modulos/contact.php">Contacto</a></li>
                        </ul>
                    </section>
                    <section class="col-lg-3 col-md-3 col-xs-12 col-sm-3 footer-two wow fadeIn">
                        <h3 class="light">Suscríbete</h3>
                            <div class="fwidget">	
                                <h5 class="light">Introduce tu Email</h5>
                                <form class="form-inline" role="form">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="subscribe" placeholder="Subscribe...">
                                        <span class="input-group-btn">
                                            <button type="submit" class="btn btn-danger">Subscribe</button>
                                        </span>
                                    </div>
		                        </form>
	                        </div>
                    </section>


                    <section class="col-lg-3 col-md-3 col-xs-12 col-sm-3 footer-one wow fadeIn">
                        <h3 class="light">Facebook</h3>
                            <div class="fwidget">
                                <script>(
                                    function(d, s, id) {
                                        var js, fjs = d.getElementsByTagName(s)[0];
                                        if (d.getElementById(id)) return;
                                        js = d.createElement(s); js.id = id;
                                        js.src = "//connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v2.5";
                                        fjs.parentNode.insertBefore(js, fjs);
                                    }(document, 'script', 'facebook-jssdk'));
                                </script>
                                <div class="fb-page" data-href="https://www.facebook.com/PartyMasterFL" data-tabs="timeline" data-height="250" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/PartyMasterFL"><a href="https://www.facebook.com/PartyMasterFL/">The PartyMasters</a></blockquote></div></div>
                                <div
                                class="fb-like"
                                data-share="true"
                                data-width="250"
                                data-show-faces="true">
                                </div>
                            </div>
                            </div>
                    </section>
                </div>
            </div>
        </div>
        <!-- /Footer Top --> 
        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-xs-12 col-sm-6 ">
                        <p class="credits">&copy; Copyright 2017 by <a href="http://wwww.jabezapp.com/">JabezApp</a></a>. All Rights Reserved. </p>
                    </div>
                    <div class="col-lg-6 col-md-6 col-xs-12 col-sm-6 ">
                        <ul class="social social-icons-footer-bottom">
                            <li class="facebook"><a href="#" data-toggle="tooltip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                            <li class="twitter"><a href="#" data-toggle="tooltip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                            <li class="dribbble"><a href="#" data-toggle="tooltip" title="Instagram"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Footer Bottom --> 
    </div>
</footer>