<?php
 /*	
	Indice
	Autor: Edni García
	Fecha: Abril 2017
*/
include_once(dirname(__FILE__). '/../config.inc');
$prefijo='../';
?>

<html> 
    <head>
        <meta charset="utf-8">
        <title>JabezApp- Contacto</title>
        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Google Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Raleway:100,200,300,700,800,900' rel='stylesheet' type='text/css'>
        <!-- Library CSS -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/bootstrap-theme.css">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/fonts/font-awesome/css/font-awesome.css">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/animations.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/superfish.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/revolution-slider/css/settings.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/revolution-slider/css/extralayers.css" media="screen">
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/prettyPhoto.css" media="screen">
        <!-- Theme CSS -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/style.css">
        <!-- Skin -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/colors/green.css" class="colors">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="<?php echo $prefijo;?>css/theme-responsive.css">
        <!-- Switcher CSS -->
        <link href="<?php echo $prefijo;?>css/switcher.css" rel="stylesheet">
        <link href="<?php echo $prefijo;?>css/spectrum.css" rel="stylesheet">
        <!-- Favicons -->
        <link rel="shortcut icon" href="<?php echo $prefijo;?>img/ico/favicon.ico">
    </head>

    <body class="home">
        <div class="page-mask">
            <div class="page-loader">
                <div class="spinner"></div>
                Loading...
            </div>
         </div>
        <?php 	
         include_once(DIR_MODULOS.'topbar.php');
		 include_once(DIR_MODULOS.'header.php');	 
		?>

<div class="breadcrumb-wrapper">
    <div class="pattern-overlay">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-xs-12 col-sm-6">
                    <h2 class="title">Contáctanos</h2>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Main Content -->
<div class="content margin-top60 margin-bottom60">
    <div class="container">
        <div class="row">
        <!-- Contact Form -->
        <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12" id="contact-form">
            <h2>Envíanos un Email</h2>
            <p>
                Por favor sea paciente mientras espera nuestra respuesta.
            </p>
            <form method="post" class="reply" id="contact">
                <fieldset>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <input class="form-control" id="name" name="name" type="text" placeholder="Nombre" value="" required>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <input class="form-control" type="email" id="email" name="email" placeholder="Email" value="" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <input class="form-control" id="subject" name="subject" type="text"  placeholder="Asunto" value="" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <textarea class="form-control" id="text" name="text" rows="3" cols="40" placeholder="Mensaje" required></textarea>
                        </div>
                    </div>
                </fieldset>
                <button class="btn btn-color submit pull-right" type="submit">Enviar</button>
                <div class="success alert-success alert" style="display:none">Your message has been sent successfully.</div>
                <div class="error alert-error alert" style="display:none">E-mail must be valid and message must be longer than 100 characters.</div>
                <div class="clearfix">
                </div>
            </form>
        </div>
        <!-- /Contact Form -->
            <div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
                <div class="address widget">
                    <h3 class="title">Contacto</h3>
                    <ul class="contact-us">  
                        <!--<i class="fa fa-www"> </i><strong> JabezApp.com</strong><br>-->
                        <i class="fa fa-phone"> </i><strong> Teléfono: </strong>  (407) 279-8544<br>
                        <i class="fa fa-envelope"> </i><strong> Email: </strong>  Jabezapp.info@gmail.com
                    </ul>
                </div>
                <div class="follow widget">
                    <h3 class="title">Síguenos</h3>
                    <div class="member-social dark">
                        <a class="facebook" href="#"><i class="fa fa-facebook"></i></a>
                        <a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
                        <a class="dribbble" href="#"><i class="fa fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Main Content -->

<!-- /Contact Form -->

        <!-- The Scripts -->
        <script src="js/jquery.min.js"></script>
        <script src="js/jquery-migrate-1.0.0.js"></script>
        <script src="js/jquery-ui.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/revolution-slider/js/jquery.themepunch.plugins.min.js"></script> 
        <script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/jquery.parallax.js"></script>
        <script src="js/jquery.wait.js"></script>
        <script src="js/fappear.js"></script> 
        <script src="js/modernizr-2.6.2.min.js"></script>
        <script src="js/jquery.bxslider.min.js"></script>
        <script src="js/jquery.prettyPhoto.js"></script>
        <script src="js/superfish.js"></script>
        <script src="js/tweetMachine.js"></script>
        <script src="js/tytabs.js"></script>
        <script src="js/jquery.gmap.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.countTo.js"></script>
        <script src="js/jflickrfeed.js"></script>
        <script src="js/imagesloaded.pkgd.min.js"></script>
        <script src="js/waypoints.min.js"></script>
        <script src="js/wow.js"></script>
        <script src="js/jquery.fitvids.js"></script>
        <script src="js/spectrum.js"></script>
        <script src="js/switcher.js"></script>
        <script src="js/custom.js"></script>
    </body>
</html>
<? 	include_once(DIR_MODULOS.'footer.php'); ?>