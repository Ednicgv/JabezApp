<?php
 /*	
	Indice
	Autor: Edni Garcia
	Fecha: Marzo 2017
*/

?>
<!-- Header -->
<header id="header">
    <!-- Main Header -->
    <div class="main-header">
        <div class="container">
            <!-- TopNav -->
            <div class="topnav navbar-header">
                <a class="navbar-toggle down-button" data-toggle="collapse" data-target=".slidedown">
                <i class="fa fa-angle-down icon-current"></i>
                </a> 
            </div>
            <!-- /TopNav-->

            <!-- Logo -->
            <div class="logo pull-left">
                <a href="index.php">
                    <img class="logo-color" src="<?php echo $prefijo;?>img/logos/logo.png" alt="gallaxy" width="200" height="105" >
                </a>
            </div>
            <!-- /Logo -->
            
            <!-- Mobile Menu -->
            <div class="mobile navbar-header">
                <a class="navbar-toggle" data-toggle="collapse" href=".navbar-collapse">
                <i class="fa fa-bars fa-2x"></i>
                </a> 
            </div>
            <!-- /Mobile Menu -->

            <!-- Menu Start -->
            <nav class="collapse navbar-collapse menu">
                <ul class="nav navbar-nav sf-menu">
                    <li>
                        <a href="<?php echo $prefijo;?>index.php">
                            HOME
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo $prefijo;?>modulos/download.php">   
                            DESCARGAS 
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo $prefijo;?>modulos/contact.php">
                            CONTACTO
                        </a>
                    </li>
                </ul>
            </nav>
            <!-- /Menu --> 
        </div>
    </div>
    <!-- /Main Header -->
</header>
<!-- /Header --> 

<!-- The Scripts -->
  <!-- The Scripts -->
        <script src="<?php echo $prefijo;?>js/jquery.min.js"></script>
        <script src="<?php echo $prefijo;?>js/jquery-migrate-1.0.0.js"></script>
        <script src="<?php echo $prefijo;?>js/jquery-ui.js"></script>
        <script src="<?php echo $prefijo;?>js/bootstrap.js"></script>
        <script src="<?php echo $prefijo;?>js/revolution-slider/js/jquery.themepunch.plugins.min.js"></script> 
        <script src="<?php echo $prefijo;?>js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
        <script src="<?php echo $prefijo;?>js/jquery.parallax.js"></script>
        <script src="<?php echo $prefijo;?>js/jquery.wait.js"></script>
        <script src="<?php echo $prefijo;?>js/fappear.js"></script> 
        <script src="<?php echo $prefijo;?>js/modernizr-2.6.2.min.js"></script>
        <script src="<?php echo $prefijo;?>js/jquery.bxslider.min.js"></script>
        <script src="<?php echo $prefijo;?>js/jquery.prettyPhoto.js"></script>
        <script src="<?php echo $prefijo;?>js/superfish.js"></script>
        <script src="<?php echo $prefijo;?>js/tweetMachine.js"></script>
        <script src="<?php echo $prefijo;?>js/tytabs.js"></script>
        <script src="<?php echo $prefijo;?>js/jquery.gmap.min.js"></script>
        <script src="<?php echo $prefijo;?>js/jquery.sticky.js"></script>
        <script src="<?php echo $prefijo;?>js/jquery.countTo.js"></script>
        <script src="<?php echo $prefijo;?>js/jflickrfeed.js"></script>
        <script src="<?php echo $prefijo;?>js/imagesloaded.pkgd.min.js"></script>
        <script src="<?php echo $prefijo;?>js/waypoints.min.js"></script>
        <script src="<?php echo $prefijo;?>js/wow.js"></script>
        <script src="<?php echo $prefijo;?>js/jquery.fitvids.js"></script>
        <script src="<?php echo $prefijo;?>js/spectrum.js"></script>
        <script src="<?php echo $prefijo;?>js/switcher.js"></script>
        <script src="<?php echo $prefijo;?>js/custom.js"></script>
        <script src="<?php echo $prefijo;?>js/jquery.isotope.js"></script>
        <script src="<?php echo $prefijo;?>js/portfolio.js"></script>